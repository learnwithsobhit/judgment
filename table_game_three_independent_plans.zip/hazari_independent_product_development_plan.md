# Hazari — Independent Digital Product and Development Plan

**Document status:** Draft v1.0  
**Audience:** Product owner, game designer, UX designer, Flutter engineers, Rust engineers, QA, data, marketing, and operations  
**Delivery model:** Independently releasable game module inside the future Table Game application  
**Recommended client/backend:** Flutter + Rust/Axum + WebSockets + PostgreSQL + Redis


## Purpose

This is the authoritative product and engineering plan for **Hazari**. A team should be able to develop and release this game without waiting for either of the other game modules. At portfolio level, the module will appear as one selectable game on the shared **Table Game Home** screen.

## Product principle

Encourage repeat play through mastery, fairness, social connection, cultural identity, and fast rematches—not through gambling pressure, fake scarcity, or purchasable advantage.

# Product scope and non-goals

## Primary audience

- Indian and South Asian players who already know Hazari;
- card-game players who enjoy optimisation and pattern construction;
- puzzle players attracted by same-hand challenges;
- diaspora families seeking a culturally familiar game.

## MVP goal

Enable a new player to learn, arrange, lock, reveal, score, and rematch a complete Hazari game with bots or invited friends. The same engine must support ranked play later without redesigning the rules.

## Non-goals for first release

- cash entry or redeemable rewards;
- public voice/text chat during ranked arrangement;
- every undocumented family rule;
- live spectators seeing private hands;
- AI that silently rearranges a ranked player's cards;
- international expansion before regional rule validation.

# Hazari game-domain specification

## State machine

```text
CREATED
 -> WAITING_FOR_PLAYERS
 -> READY_CHECK
 -> SHUFFLE_COMMITTED
 -> DEALING
 -> ARRANGING
 -> ALL_LOCKED
 -> REVEAL_GROUP_1
 -> REVEAL_GROUP_2
 -> REVEAL_GROUP_3
 -> REVEAL_GROUP_4
 -> DEAL_SCORING
 -> NEXT_DEAL | MATCH_COMPLETE
```

## Core commands

```text
ready
move_card_to_group
reorder_group
request_arrangement_validation
lock_arrangement
submit_private_prediction
ack_reveal
request_reconnect_snapshot
```

Only `lock_arrangement` and predictions need server authority during arrangement. UI card movement may remain local until validation/lock, reducing network chatter.

## Core events

```text
deal_started
private_hand_dealt
player_locked
all_players_locked
group_revealed
group_winner_resolved
cards_captured
deal_score_updated
match_winner_resolved
```

## Essential invariants

- exactly 52 unique cards exist;
- every active player owns exactly 13 cards before reveal;
- group sizes are 3, 3, 3, and 4;
- groups satisfy the configured strength ordering;
- a locked arrangement cannot change;
- every revealed card belongs to the revealing player;
- captured points per deal equal the configured deck total;
- tie resolution follows the persisted rule pack.

# Hazari screen map

```text
Home Game Card
 -> Hazari Overview
 -> Learn / Play
 -> Mode Selection
 -> Rule Pack
 -> Lobby or Matchmaking
 -> Arrangement Table
 -> Lock Confirmation
 -> Four Reveal Rounds
 -> Deal Score
 -> Match Result
 -> Insight / Replay / Rematch
```

Required arrangement UX:

- four clearly named trays;
- combination labels and tie-break preview;
- legality indication without strategic recommendation in ranked play;
- card-value summary;
- manual sort and optional beginner assist;
- safe lock confirmation;
- reconnect restoration before timer expiry.

# Hazari delivery backlog

## Epic HZ-1: Rules and simulation

- implement card and combination model;
- implement all tie-breaks;
- validate 3-3-3-4 ordering;
- implement scoring;
- create bot simulation harness;
- add named rule-pack fixtures.

## Epic HZ-2: Arrangement experience

- card trays;
- drag/tap interaction;
- legality feedback;
- grouping suggestions for tutorial only;
- timer and lock;
- accessibility and landscape layouts.

## Epic HZ-3: Match lifecycle

- bot match;
- private room;
- reconnect;
- reveal orchestration;
- scoring and match completion;
- replay.

## Epic HZ-4: Strategy and retention

- Mirror Hazari;
- daily partition puzzle;
- prediction mastery;
- post-match strength curve;
- expected-capture coach.

## Epic HZ-5: Competitive systems

- solo ranked queue;
- multiplayer rating;
- seat rotation;
- identity hiding;
- repeated-pair monitoring;
- seasonal divisions.

# Hazari release stages

## Alpha

- bots only;
- one validated rule pack;
- arrangement and reveal;
- local analytics;
- no account economy.

## Private beta

- invited multiplayer;
- reconnect;
- two languages;
- rule feedback tool;
- replay verifier.

## Public MVP

- bot and private play;
- stable rule pack;
- tutorial;
- cosmetics/ad-free entitlement;
- support and reporting.

## Competitive release

- ranked Championship;
- Mirror leaderboard;
- anti-collusion analytics;
- seasonal divisions;
- advanced insight.

# Hazari definition of done

The initial independent game is complete when:

- all critical rules are covered by tests;
- a user can enter from Table Game Home and return without shell restart;
- four players can complete and resume a match;
- no private card appears in another player's snapshot or logs;
- replay reproduces every reveal and score;
- one game can be disabled through a feature flag;
- p95 accepted-command latency meets the regional target;
- crash-free match sessions exceed the release target;
- product, rule expert, QA, security, and accessibility reviews sign off.

# Detailed game product design

## Core rules to implement

Hazari is generally documented as a four-player game using a 52-card deck. Each player receives 13 cards and partitions the hand into groups of 3, 3, 3, and 4 cards, ordered from strongest to weakest.

Common combination order:

1. Troy/Trial
2. Colour Run
3. Run
4. Colour
5. Pair
6. Indi/Individual

The players compare their strongest groups, then the next groups. The winner of each comparison captures the cards and their point values. A common scoring system gives 10 points to A, K, Q, J, and 10, and 5 points to 2–9, giving 360 points in a deal. Play commonly continues until a player reaches at least 1,000 points.

Regional variations affect:

- card-point values;
- the fourth four-card group;
- tie resolution;
- special instant-win conditions;
- direction of play.

The product must use named rule packs.

## Product problems

### Dense arrangement decision

A beginner must understand combinations, tie-breaking, group ordering, and whether a strong first group weakens the rest of the hand.

### Low interactivity after lock

Once all groups are fixed, the rest is mainly reveal and comparison. Poor animation pacing makes the game feel passive.

### Deal luck

One deal is too noisy for serious ranking.

### Limited but possible collusion

Players cannot normally alter groups after locking, which reduces live side-channel value. However, players who privately share hands before locking could still coordinate weak partitions or point transfer.

### Weak digital differentiation

Many current apps emphasise offline bots, virtual coins, daily bonuses, and casino-style rooms. That leaves space for a skill-first product.

## Product thesis

> **Turn Hazari into a competitive hand-construction game, not a four-step card reveal.**

Core emotional loop:

1. Receive a chaotic 13-card hand.
2. Discover structures.
3. Choose top-heavy or balanced strength.
4. Lock the partition.
5. Watch four escalating comparisons.
6. Learn whether the structure was robust.

## Modes

### Hazari Classic

- Four players or bots;
- authentic 3-3-3-4 arrangement;
- named regional rules;
- casual and ranked queues;
- no cash stakes.

### Quick Hazari

- One deal;
- 4–6 minutes;
- unranked or minimal rating weight.

### Hazari Championship

- Continue to 1,000 points;
- dealer and seats rotate;
- ranked;
- reconnect and resume support.

### Mirror Hazari — proposed new mode

All competitors receive the **same virtual 13-card hand on isolated boards** and arrange it independently.

Score using:

- expected capture against fixed simulated opponent deals;
- balance across four groups;
- robustness;
- arrangement time;
- prediction accuracy.

Benefits:

- removes deal luck;
- prevents in-match collusion;
- creates a pure partition-skill rating;
- supports asynchronous daily challenges;
- creates shareable “How did you split this?” discussions.

This should be Hazari’s most important digital invention.

### Hazari Duel — proposed new mode

Two players receive cloned copies of the same 13-card hand and create partitions. Their groups are compared directly.

Possible format:

- one point per group won;
- card value as tie-breaker;
- best of five hands.

This is a modern digital variant and must be clearly labelled.

### Contract Hazari — proposed new mode

After arranging, a player privately selects a contract:

- **Balanced:** win at least two groups;
- **Crown:** win the first group;
- **Vault:** win the final four-card group;
- **Sweep:** win at least three groups;
- **Underdog:** win a group using Pair or Indi.

Successful contracts grant mastery XP or cosmetics, not cash or competitive power.

### Hazari Lab

Daily puzzles:

- strongest legal ordering;
- maximum expected captured value;
- protect high-value cards;
- identify illegal arrangements;
- choose between two partitions;
- predict the weakest group.

## New strategic layers

### Strength distribution

A novice maximises Group 1. An expert asks whether one near-certain win is worth three weak groups.

Post-match display:

- Group 1 percentile;
- Group 2 percentile;
- Group 3 percentile;
- Group 4 percentile.

### Point protection

Combination strength and card value are not identical. A player may want to protect high-value cards even when that reduces the peak combination.

Add a post-match capture-value map.

### Robustness

An arrangement may be strong against average hands but fragile against common patterns.

The coach can simulate legal opponent deals and estimate:

- group win probability;
- expected card points;
- variance;
- top-heavy versus balanced profile.

### Prediction

Before reveal, players privately predict:

- groups they will win;
- final point range;
- most dangerous opponent group.

Prediction accuracy becomes a mastery statistic, not part of classic score.

## UX

Arrangement interface:

- four clearly labelled trays;
- tap or drag interactions;
- combination name on each tray;
- legal/illegal state;
- undo until Lock/Up;
- full assist, legality-only assist, and expert modes;
- no strategic recommendation in ranked play.

Reveal rhythm:

1. Focus table.
2. Flip all groups.
3. Show combination labels.
4. Highlight winner.
5. Move captured points.
6. Pause briefly.
7. Continue.

Post-match show only:

- one good choice;
- one missed alternative;
- one personal trend.

## Ranking and integrity

For Classic Hazari use TrueSkill or a Plackett–Luce-style multiplayer model.

Rank only:

- multi-deal matches;
- solo queue;
- hidden identities until completion;
- no parties;
- no arrangement chat;
- limited repeated opponents.

Rating inputs:

- final placement;
- point margin;
- opponent strength;
- number of deals;
- uncertainty.

Mirror Hazari can use a Glicko-style or percentile rating because participants receive comparable challenges.

Fairness systems:

- secure server RNG;
- shuffle commitment before deal;
- verification after match;
- deterministic replay;
- seat rotation;
- reconnect time bank;
- explicit bot-takeover policy;
- collusion graph analysis;
- no engagement-optimised hidden matchmaking.

## AI

Start with:

1. legal partition generator;
2. exact combination evaluator;
3. heuristic scorer;
4. Monte Carlo opponent simulation;
5. style layer.

Bot styles:

- Top-Heavy Raja;
- Balanced Architect;
- Point Hunter;
- Risky Sweeper;
- Beginner Bot.

Coach explanations should discuss expected value and uncertainty rather than presenting one partition as absolute truth.

## Monetisation

Use:

- card backs and tables;
- regional art packs;
- ad-free purchase;
- advanced analysis subscription;
- club customisation;
- profile frames;
- non-expiring season progression.

Avoid:

- boot coins that block play;
- paid ranked hints;
- redeemable currency;
- cash prizes;
- “double or lose” offers.

## Hazari MVP

Must have:

- configurable rules engine;
- exact combination evaluator;
- partition validation;
- arrangement UI;
- offline bots;
- private rooms;
- reconnect;
- deterministic replay;
- scoring to 1,000;
- tutorial;
- multilingual foundation;
- telemetry;
- accessibility controls.

Next:

- ranked matchmaking;
- Mirror Hazari;
- daily puzzles;
- coach;
- clubs;
- cosmetics.

## Hazari go/no-go criteria

Proceed only when:

- 70%+ of target users accept the selected rule packs;
- 75% can create a legal partition after two tutorials;
- median arrangement time is below 90 seconds by match five;
- 30%+ request a rematch;
- 85% understand why the winning group won;
- 60%+ of experienced users find Mirror Hazari compelling.

---

# Engagement and psychology model

## The problem with simply copying cards onto a screen

A technically correct digital implementation can still feel flat because the physical game also contains:

- face-to-face reactions;
- teasing and conversation;
- tactile card handling;
- visible shuffling;
- natural teaching;
- family rules and cultural identity;
- frictionless rematches.

A screen removes much of this. If the product only reproduces card movement, it preserves rules but loses experience.

## Root cause

Players return when the game repeatedly satisfies five needs:

1. **Competence:** “I am understanding and improving.”
2. **Autonomy:** “I chose my strategy and preferred way to play.”
3. **Relatedness:** “I played with people who mattered or felt socially connected.”
4. **Fairness:** “Cards, scoring, matchmaking, and opponents were trustworthy.”
5. **Rhythm:** “The match moved cleanly through anticipation, choice, reveal, and resolution.”

Self-Determination Theory research on games associates autonomy, competence, and relatedness with enjoyment and future play. It also connects intuitive controls with competence and immersion. Research on leaderboards suggests that points and ranks may guide performance, but do not create intrinsic enjoyment by themselves. Research on flow indicates that challenge should remain near the player’s skill level.

## So how can we solve the problem?

Build a **mastery-first retention loop**:

1. Give the player a meaningful decision.
2. Make the result understandable.
3. Show one useful learning insight.
4. Offer a quick rematch or a related challenge.
5. Make progression visible without punishing the player for taking a break.

The game should be enjoyable before rewards are added.

---

# Psychology-backed product rules

## Competence

Every completed match should answer:

- Which decision mattered most?
- What happened because of it?
- What could I try next time?

Implement:

- one post-match insight rather than a lecture;
- skill-specific statistics;
- decision bookmarks in replay;
- optional explanations;
- beginner leagues;
- personal-best progress.

Avoid:

- unexplained rating movement;
- humiliating loss screens;
- bots presented as humans;
- random prizes portrayed as skill.

## Autonomy

Let players choose:

- Classic versus modern modes;
- ranked, casual, private, puzzle, or bot play;
- animation speed;
- manual or assisted sorting;
- preferred match duration;
- language, card design, and table theme;
- whether the coach is enabled.

Do not force unnecessary reward screens before a rematch.

## Relatedness

Use:

- immediate rematches;
- friend links and room codes;
- clubs based on family, city, workplace, or language;
- preset respectful reactions;
- post-match reactions;
- shareable replay moments;
- teach-a-friend rooms.

For child-accessible modes, do not expose unrestricted stranger chat.

## Flow

Use:

- calibrated matchmaking;
- bot personalities and difficulty bands;
- adaptive tutorials;
- separate fast and thoughtful queues;
- turn-time banks;
- protection from early expert mismatches.

## Leaderboards

A global leaderboard mainly motivates elite players. Most users need a reachable comparison.

Offer:

- friends;
- nearby rating group;
- city and region;
- club;
- weekly improvement;
- skill-specific badges;
- seasonal division;
- global elite.

Show roughly 20 players around the user’s level rather than only one huge global rank.

## Ethical guardrails

Do not use:

- streaks that reset to zero after one missed day;
- fake scarcity;
- fake countdowns;
- forced invitations;
- loss-chasing offers;
- pay-to-win items;
- coin bankruptcy that blocks normal play;
- undisclosed reward odds;
- rigged card sequences;
- hidden bot substitution;
- artificial near-miss animations.

Use:

- optional reminders;
- resumable progress;
- transparent pricing;
- session-end summaries;
- play-time controls;
- no penalty for taking a break;
- cosmetic and learning-based purchases.

---

# Technical architecture and independent-delivery boundary

## Independence rule

This game must be independently buildable, testable, deployable, and releasable. It may reuse platform packages, but it must not import another game's rules, state, screens, ranking logic, or release lifecycle.

Use these dependency rules:

- `table_game_home` may depend on the game integration interface.
- The game presentation package may depend on shared UI primitives.
- The game feature package may depend on its own rules client and shared platform clients.
- The server game adapter may depend on its own pure rules crate and shared infrastructure abstractions.
- The pure rules crate must not depend on Flutter, Axum, databases, Redis, analytics, payments, or another game.
- Shared infrastructure must not contain game-specific scoring rules.

This allows one game to be disabled, upgraded, rolled back, or regionally restricted without affecting the others.

## Recommended repository structure

```text
apps/
  table_game_flutter/
    lib/
      home/
      shared_cards/
      shared_lobby/
      shared_profile/
      games/hazari/
services/
  table_game_api/
crates/
  game_platform_core/
  game_protocol/
  rating_core/
  replay_core/
  fairness_core/
  hazari_core/
  hazari_server/
```

A modular monorepo is recommended initially. The boundaries should be strong enough to extract a game service later if scale or team ownership requires it.

## Client architecture

Recommended client: **Flutter** for Android, iOS, and Web.

Layers:

1. **Presentation:** screens, card layouts, animation, sound, accessibility.
2. **Feature controller:** maps server events to UI state and sends commands.
3. **Game protocol client:** typed commands, events, snapshots, version negotiation.
4. **Shared platform clients:** account, lobby, friends, inventory, analytics, remote configuration.

The client is never authoritative for shuffle, legal moves, scoring, hidden information, match completion, or rating changes.

## Backend architecture

Recommended backend: **Rust + Axum**, with WebSockets for live matches.

Core components:

- identity and profile;
- game catalogue;
- lobby and room service;
- matchmaking;
- authoritative match session;
- game-specific server adapter;
- deterministic rules crate;
- secure shuffle and fairness proof;
- event log and replay;
- rating service where applicable;
- anti-abuse and reporting;
- inventory and purchases;
- analytics export.

Use PostgreSQL for durable user, match, rating, inventory, and purchase data. Use Redis for ephemeral rooms, matchmaking queues, presence, and short reconnect snapshots. The authoritative event log must be durably persisted before competitive rewards are finalized.

## Deterministic rules interface

```rust
pub trait CardGame {
    type Command;
    type Event;
    type State;
    type PublicConfig;
    type PlayerView;

    fn initial_state(config: Self::PublicConfig) -> Self::State;
    fn validate(
        state: &Self::State,
        actor: PlayerId,
        command: &Self::Command,
    ) -> Result<(), RuleError>;
    fn apply(
        state: &mut Self::State,
        actor: PlayerId,
        command: Self::Command,
    ) -> Result<Vec<Self::Event>, RuleError>;
    fn view_for(state: &Self::State, viewer: Viewer) -> Self::PlayerView;
}
```

Rules requirements:

- deterministic transitions;
- no duplicate or missing cards;
- hidden-information redaction;
- replay from events;
- versioned rule packs;
- property-based tests;
- bot and simulator hooks;
- forward-compatible event envelopes.

## WebSocket protocol

Client commands:

```text
join_match
ready
submit_game_action
request_snapshot
ack_event
leave_match
report_player
```

Server messages:

```text
match_joined
match_snapshot
match_event
command_rejected
turn_timer
player_connection_changed
match_completed
rating_updated
```

Every envelope should include:

```json
{
  "protocol_version": 1,
  "game_id": "hazari",
  "match_id": "uuid",
  "sequence": 42,
  "message_type": "match_event",
  "payload": {}
}
```

Commands need client-generated idempotency IDs. Events need monotonically increasing server sequence numbers.

## Fair shuffle and replay

Recommended competitive flow:

1. Generate a cryptographically secure server seed.
2. Publish a commitment hash before the deal.
3. Shuffle server-side using a documented algorithm and version.
4. Persist the seed securely with the match record.
5. Reveal verification material after the match where safe.
6. Reproduce the deal in a replay verifier.

Never expose seed material during a live match. Casual bot matches may use a simpler path, but must still avoid engagement-based card manipulation.

## Reliability

- Reconnect restores a player-specific redacted snapshot.
- Replayed commands are idempotent.
- Server timeout policy is part of the rule pack.
- Competitive match completion survives a service restart.
- A rules-version identifier is persisted with every match.
- Client versions that cannot interpret the active protocol are rejected before queue entry.

## Testing strategy

Required automated tests:

- unit tests for every rule and tie-break;
- property-based card conservation;
- hidden-view leakage tests;
- deterministic replay tests;
- command fuzzing;
- invalid-turn tests;
- timer expiry tests;
- reconnect and duplicate-command tests;
- bot-versus-bot simulation;
- client golden tests for important states;
- accessibility tests for card readability and touch targets;
- load tests for concurrent rooms.

# Table Game Home integration contract

The Table Game Home screen is a catalogue and launcher. It must not understand game-specific rules.

## Game manifest

Each game publishes a versioned manifest:

```json
{
  "game_id": "hazari",
  "display_name": "Hazari",
  "short_description": "Arrange four groups, reveal them, and race to 1,000 points.",
  "icon_asset": "assets/games/hazari/icon.webp",
  "hero_asset": "assets/games/hazari/hero.webp",
  "minimum_players": 4,
  "maximum_players": 4,
  "supports_bots": true,
  "supports_private_rooms": true,
  "supports_ranked": true,
  "supports_async": true,
  "minimum_client_version": "1.0.0",
  "rule_pack_version": "1.0.0",
  "availability": {
    "regions": ["IN"],
    "platforms": ["android", "ios", "web"]
  },
  "entry_routes": {
    "overview": "/games/hazari",
    "play": "/games/hazari/play",
    "resume": "/games/hazari/resume/{match_id}"
  }
}
```

## Home-screen card

The home card should show only platform-level information:

- game artwork and title;
- one-line value proposition;
- player-count range;
- estimated match duration;
- `Play`, `Learn`, and `Resume` states;
- current event or season badge;
- installation/download state if feature modules are used.

Do not expose complicated rule options on the home screen. Those belong in the game's lobby.

## Launch interface

```dart
abstract interface class TableGameModule {
  String get gameId;
  Future<void> preload(GameLaunchContext context);
  Widget buildOverview(GameLaunchContext context);
  Widget buildLobby(GameLaunchContext context);
  Widget buildMatch(GameSession session);
  Widget buildReplay(String matchId);
  Future<bool> canResume(String matchId);
}
```

The home shell supplies authentication, locale, accessibility preferences, sound preferences, connectivity, profile summary, and deep-link parameters.

## Shared navigation

Every game must support:

```text
Home -> Game Overview -> Mode Selection -> Lobby/Matchmaking
     -> Match -> Result -> Rematch or Game Overview -> Home
```

Android back, browser back, app resume, and deep links must preserve the same state model.

## Shared identity and progression

Keep two layers separate:

- **Table Game profile:** avatar, friends, club, account level, cosmetics inventory, safety settings.
- **Game profile:** game rating, game mastery, game statistics, tutorials, badges, rule preferences.

A player can have a high platform level while remaining a beginner in a newly selected game.

## Shared economy

Permitted shared purchases:

- universal card backs;
- avatars;
- table themes where compatible;
- ad-free entitlement;
- optional family or analysis subscription.

Game rules, shuffle odds, ranked entry, hints during ranked play, and competitive powers must never be purchasable.

## Shared analytics envelope

Every event must contain:

```text
user_id or anonymous_id
session_id
game_id
game_version
rule_pack
mode
match_id when applicable
platform
region
experiment_assignments
timestamp
```

Common event names:

```text
game_card_viewed
game_selected
tutorial_started
tutorial_completed
queue_joined
match_started
match_completed
match_abandoned
rematch_selected
replay_opened
purchase_started
purchase_completed
report_submitted
```

Game-specific events belong to a namespaced schema.

## Feature flags and release isolation

Each game requires independent flags for:

- home visibility;
- new-player access;
- ranked queue;
- private rooms;
- bot play;
- experiments;
- monetisation;
- region availability;
- minimum version;
- emergency kill switch.

A failure in one game must not prevent the home screen or another game from loading.

# Research foundations used in this plan

The design decisions draw on the following research themes:

- Self-Determination Theory: autonomy, competence, and relatedness support enjoyment and continued play.
- Flow: challenge should remain close to skill, with manageable uncertainty and immediate feedback.
- Gamification research: points and leaderboards are feedback mechanisms, not substitutes for intrinsic fun.
- Competition and cheating research: an excessive focus on prizes and status can increase win-at-all-costs behaviour.
- Dark-pattern research: temporal, monetary, social, and psychological pressure may increase short-term activity while harming trust and wellbeing.
- Player- and data-driven balancing: simulations should be combined with interviews, observed sessions, and production telemetry.

Core references:

1. Ryan, Rigby, and Przybylski. *The Motivational Pull of Video Games: A Self-Determination Theory Approach*.
2. Moller, Kornfield, and Lu. *Competition and Digital Game Design: A Self-Determination Theory Perspective*.
3. Mekler et al. *Do Points, Levels and Leaderboards Harm Intrinsic Motivation?*
4. Larche et al. *The Relationship Between Skill-Challenge Balance, Game Expertise, Flow and the Urge to Keep Playing*.
5. Lee et al. *The Influence of Psychological Needs and Motivation on Game Cheating*.
6. Aagaard et al. *A Game of Dark Patterns: Designing Healthy, Highly-Engaging Mobile Games*.
7. Pfau and El-Nasr. *On Video Game Balancing: Joining Player- and Data-Driven Analytics*.
Additional Hazari sources:

- Pagat, *Hazari rules and regional descriptions*.
- Expert interviews and recorded physical sessions are required because regional rules vary.
- Monte Carlo partition evaluation and human expert review should jointly guide the strategy coach.

