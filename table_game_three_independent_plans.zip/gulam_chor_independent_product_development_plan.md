# Gulam Chor — Independent Digital Product and Development Plan

**Document status:** Draft v1.0  
**Audience:** Product owner, game designer, UX designer, Flutter engineers, Rust engineers, QA, data, marketing, and operations  
**Delivery model:** Independently releasable game module inside the future Table Game application  
**Recommended client/backend:** Flutter + Rust/Axum + WebSockets + PostgreSQL + Redis


## Purpose

This is the authoritative product and engineering plan for **Gulam Chor**. A team should be able to develop and release this game without waiting for either of the other game modules. At portfolio level, the module will appear as one selectable game on the shared **Table Game Home** screen.

## Product principle

Encourage repeat play through mastery, fairness, social connection, cultural identity, and fast rematches—not through gambling pressure, fake scarcity, or purchasable advantage.

# Product scope and non-goals

## Primary audience

- Indian families and friend groups;
- children playing with parent-controlled settings;
- casual users who prefer short humorous games;
- party players invited through room links.

## MVP goal

Create the easiest social game in the Table Game application: a player should understand it within one minute, create or join a private room, complete a round, enjoy the final Chor reveal, and rematch immediately.

## Non-goals for first release

- presenting Classic Gulam Chor as a serious skill esport;
- unrestricted stranger chat;
- cash play or redeemable rewards;
- purchasable tactical powers;
- lengthy account setup before private-room play;
- deceptive signals that secretly identify the Chor.

# Gulam Chor game-domain specification

## State machine

```text
CREATED
 -> WAITING_FOR_PLAYERS
 -> READY_CHECK
 -> SHUFFLE_COMMITTED
 -> DEALING
 -> INITIAL_PAIR_REMOVAL
 -> TURN_OFFER
 -> TURN_DRAW
 -> NEW_PAIR_REMOVAL
 -> PLAYER_FINISHED | NEXT_TURN
 -> ONE_CARD_REMAINS
 -> CHOR_REVEAL
 -> ROUND_COMPLETE
 -> REMATCH | SESSION_COMPLETE
```

Detective and Bluff modes add prediction and hand-presentation substates without changing Classic rules.

## Core commands

```text
ready
confirm_initial_pairs
reorder_offered_cards
select_hidden_card
submit_detective_prediction
use_mode_tactic
send_safe_reaction
request_reconnect_snapshot
```

## Core events

```text
round_started
private_hand_dealt
pairs_removed
turn_started
offer_locked
card_selected_private
card_transferred
new_pair_removed
player_finished
detective_prediction_recorded
chor_revealed
round_result
```

## Essential invariants

- the configured deck contains exactly one unmatched target Jack;
- all other cards can ultimately form equal-rank pairs;
- selected cards are hidden until transfer resolution;
- a finished player owns no cards;
- turn direction follows the rule pack or public tactic event;
- no cosmetic asset changes card geometry or probability;
- Classic mode contains no paid or random gameplay powers.

# Gulam Chor screen map

```text
Home Game Card
 -> Gulam Chor Overview
 -> Family / Classic / Fast / Detective
 -> Create Room / Join Code / Bots
 -> Pair Removal
 -> Offer Cards
 -> Draw Card
 -> Finished-Player Detective View
 -> Final Chor Reveal
 -> Fun Awards / Rematch
```

Critical UX:

- large hidden-card fan;
- equal touch areas;
- clear draw direction;
- no opponent pointer preview before commitment;
- fast pair-removal animation;
- strong final reveal;
- immediate Detective participation after finishing;
- safe preset reactions;
- parental controls and muted-by-default stranger communication.

# Gulam Chor delivery backlog

## Epic GC-1: Classic rules

- odd-Jack configuration;
- deal and pair removal;
- draw direction;
- card transfer;
- finish detection;
- final Chor resolution.

## Epic GC-2: Social room

- room code and deep link;
- bot fill;
- host controls;
- reconnect;
- safe reactions;
- instant rematch.

## Epic GC-3: Family UX

- one-minute tutorial;
- large-card accessibility;
- sound and animation controls;
- parental purchase lock;
- report/mute;
- child-safe default settings.

## Epic GC-4: Strategic extension

- Detective predictions;
- finished-player participation;
- manual hand presentation;
- Bluff Master metrics;
- Chor Relay multi-round scoring.

## Epic GC-5: Content and monetisation

- characters;
- tables and card backs;
- story chase;
- family pass;
- local-language reactions;
- no paid powers.

# Gulam Chor release stages

## Alpha

- bot and pass-and-play;
- Classic rules;
- final reveal;
- telemetry.

## Private beta

- room codes;
- reconnect;
- bot fill;
- safe reactions;
- family testing.

## Public MVP

- private and casual public rooms;
- Classic and Fast modes;
- cosmetics/ad-free;
- parental controls;
- moderation/reporting.

## Engagement release

- Detective Mode;
- Bluff Master;
- Chor Relay;
- story content;
- family clubs/events.

# Gulam Chor definition of done

The initial independent game is complete when:

- a first-time user can complete a round without external explanation;
- card selection has no measurable geometric bias;
- private rooms reliably reconnect and rematch;
- finished players transition correctly to spectator/Detective state;
- no open stranger chat is exposed in child-accessible flows;
- all purchases are cosmetic or content-based;
- replay reconstructs the route of the Chor;
- the home shell can launch, resume, and disable the module independently;
- safety, accessibility, rule, QA, and production reviews pass.

# Detailed game product design

## Core rules to implement

Gulam Chor is the Jack-based Indian form of Old Maid/Jack Thief.

Typical play:

- 2–8 players;
- standard deck;
- leave an odd number of Jacks so one remains unmatched;
- deal all cards;
- discard equal-rank pairs;
- draw a hidden card from the next player;
- discard any new pair;
- the final player holding the unmatched Jack loses.

Some families remove one Jack; others leave one designated Jack. Support both as named house rules.

## Product problems

### Low classic skill depth

Luck strongly affects who receives the Chor. Physical strategy comes from memory, reactions, card presentation, and bluffing, but digital play removes many face-to-face tells.

### Idle finished players

A player who discards all cards can become a passive spectator.

### Misleading rankings

Classic win/loss is too random for a serious skill ladder.

### Child-accessible audience

The product needs stronger privacy, safety, monetisation, and chat controls.

### Unproven market

Dedicated digital apps have a much smaller visible footprint than major rummy products. The opportunity is open, but demand requires validation.

## Product thesis

> **Make Gulam Chor a comedy-and-bluff party game, not a fake serious casino game.**

Core loop:

1. Discover the Chor.
2. Hide your reaction.
3. Arrange the offered cards.
4. Tempt the next player toward or away from it.
5. Watch the Chor travel.
6. Enjoy the final reveal.

## Modes

### Classic Gulam Chor

- authentic family rules;
- 3–8 players;
- bots or real players;
- 5–10 minutes;
- no serious skill rank.

### Family Room

- private room code;
- house rules;
- optional unlimited turn time;
- preset safe reactions;
- pass-and-play;
- parental purchase controls.

### Fast Chor

- reduced deck based on player count;
- 2–4 minutes;
- rapid rematches.

### Detective Mode — proposed new mode

Every few turns, active and finished players privately predict:

- current Chor holder;
- likely position in the offered fan;
- next player to finish.

Correct predictions grant Detective Points without altering classic result.

Benefits:

- adds inference;
- keeps finished users engaged;
- creates a genuine individual mastery metric;
- makes spectating active.

### Bluff Master — proposed new mode

Before offering cards, a player can:

- manually arrange positions;
- choose a neutral presentation animation;
- attach an optional preset expression.

Measure skill using:

- how often opponents select the Chor compared with random expectation;
- how often the player correctly avoids it;
- prediction accuracy;
- memory performance.

Cosmetics must never create visual signals that affect fairness.

### Chor Masala — proposed new mode

Each player receives one public, single-use tactic:

- **Shuffle:** reorder after an opponent chooses a zone but before final card selection;
- **Reverse:** reverse direction;
- **Peek:** reveal one non-Chor card briefly;
- **Shield:** protect one position for one turn;
- **Swap Seats:** change draw relationship;
- **Double Clue:** receive an extra Detective clue.

Rules:

- no paid powers;
- one use per match;
- separate queue from Classic;
- simulate balance before release.

### Story Chase

Single-player chapters with characters that use different bluff styles. Use regional visual themes and teach one mechanic per chapter.

### Chor Relay — proposed new mode

Play several short rounds and score:

- finishing order;
- detective accuracy;
- bluff success;
- memory performance.

This is a fairer competition than one classic result.

## Strategic layers

### Hand presentation

Allow controlled manual ordering and spacing.

Possible strategies:

- hide the Chor in the middle;
- use an edge repeatedly;
- create a visible decoy;
- establish a pattern, then break it.

### Rank tracking

As pairs disappear, players can infer remaining ranks. Training mode can show a memory board; advanced mode removes it and scores recall.

### Bluff baseline

Measure whether a player changes opponent selection beyond random chance. This turns presentation into measurable skill.

### Prediction economy

Detective Points cannot be spent to alter the current match. That prevents snowballing.

## UX

Card offering:

- large touch targets;
- clear card fan;
- no accidental double tap;
- fixed card-back size;
- optional confirmation for accessibility;
- hide opponent finger movement until selection commits.

Suspense:

- subtle heartbeat;
- haptic pulse;
- quick transfer animation;
- comic reaction after draw;
- no false clue that reveals the card.

Finished-player mode:

- immediate Detective view;
- private predictions;
- reactions;
- contribution XP.

Final reveal:

- freeze table;
- reveal Jack;
- show travel path;
- longest holder;
- best bluff;
- best detective;
- immediate rematch.

## Ranking

Do not use Classic wins as the only rank.

Use three systems:

### Social level

- participation-based;
- never decreases;
- unlocks cosmetics.

### Party season score

- multi-round finishing positions;
- moderate competitive meaning.

### Skill badges

- Detective accuracy;
- memory accuracy;
- bluff success against random baseline;
- safe-draw rate adjusted for available information;
- consistency.

For Bluff Master or Chor Relay, test a composite rating such as:

- 35% finish performance;
- 30% detective accuracy;
- 25% bluff effectiveness;
- 10% memory.

Weights must be validated, not assumed.

## AI

Bot personalities:

- Random Raju;
- Memory Meena;
- Bluffing Bunty;
- Pattern Priya;
- Detective Dadi.

AI should model:

- card-position preference;
- memory errors;
- bluffing;
- reaction timing;
- prediction.

Do not give bots perfect memory at normal difficulties.

## Monetisation

Use:

- characters;
- card backs;
- table environments;
- comic animations;
- family pass;
- ad-free purchase;
- safe emotes;
- story chapters.

Avoid:

- paid tactical powers;
- paid peeks;
- ads during turns;
- child-directed pressure;
- stranger chat;
- loot boxes.

## Gulam Chor MVP

Must have:

- configurable odd-Jack setup;
- pair-removal engine;
- turn-based drawing;
- bots;
- 3–6 player private rooms;
- reconnect;
- spectator state;
- safe reactions;
- tutorial;
- family settings;
- animation and sound controls.

Next:

- public casual matchmaking;
- Detective Mode;
- manual hand presentation;
- Bluff Master;
- story mode;
- cosmetics.

## Gulam Chor go/no-go criteria

Proceed to significant public investment if:

- 40%+ of private rooms play at least three rounds;
- Detective mode keeps 60%+ of finished players active;
- 80% understand manual presentation without lengthy explanation;
- adults and children can both complete their first match;
- users describe the game as funny or social, not merely random;
- users show cosmetic interest without tactical purchases.

---

# Engagement and psychology model

## The problem with simply copying cards onto a screen

A technically correct digital implementation can still feel flat because the physical game also contains:

- face-to-face reactions;
- teasing and conversation;
- tactile card handling;
- visible shuffling;
- natural teaching;
- family rules and cultural identity;
- frictionless rematches.

A screen removes much of this. If the product only reproduces card movement, it preserves rules but loses experience.

## Root cause

Players return when the game repeatedly satisfies five needs:

1. **Competence:** “I am understanding and improving.”
2. **Autonomy:** “I chose my strategy and preferred way to play.”
3. **Relatedness:** “I played with people who mattered or felt socially connected.”
4. **Fairness:** “Cards, scoring, matchmaking, and opponents were trustworthy.”
5. **Rhythm:** “The match moved cleanly through anticipation, choice, reveal, and resolution.”

Self-Determination Theory research on games associates autonomy, competence, and relatedness with enjoyment and future play. It also connects intuitive controls with competence and immersion. Research on leaderboards suggests that points and ranks may guide performance, but do not create intrinsic enjoyment by themselves. Research on flow indicates that challenge should remain near the player’s skill level.

## So how can we solve the problem?

Build a **mastery-first retention loop**:

1. Give the player a meaningful decision.
2. Make the result understandable.
3. Show one useful learning insight.
4. Offer a quick rematch or a related challenge.
5. Make progression visible without punishing the player for taking a break.

The game should be enjoyable before rewards are added.

---

# Psychology-backed product rules

## Competence

Every completed match should answer:

- Which decision mattered most?
- What happened because of it?
- What could I try next time?

Implement:

- one post-match insight rather than a lecture;
- skill-specific statistics;
- decision bookmarks in replay;
- optional explanations;
- beginner leagues;
- personal-best progress.

Avoid:

- unexplained rating movement;
- humiliating loss screens;
- bots presented as humans;
- random prizes portrayed as skill.

## Autonomy

Let players choose:

- Classic versus modern modes;
- ranked, casual, private, puzzle, or bot play;
- animation speed;
- manual or assisted sorting;
- preferred match duration;
- language, card design, and table theme;
- whether the coach is enabled.

Do not force unnecessary reward screens before a rematch.

## Relatedness

Use:

- immediate rematches;
- friend links and room codes;
- clubs based on family, city, workplace, or language;
- preset respectful reactions;
- post-match reactions;
- shareable replay moments;
- teach-a-friend rooms.

For child-accessible modes, do not expose unrestricted stranger chat.

## Flow

Use:

- calibrated matchmaking;
- bot personalities and difficulty bands;
- adaptive tutorials;
- separate fast and thoughtful queues;
- turn-time banks;
- protection from early expert mismatches.

## Leaderboards

A global leaderboard mainly motivates elite players. Most users need a reachable comparison.

Offer:

- friends;
- nearby rating group;
- city and region;
- club;
- weekly improvement;
- skill-specific badges;
- seasonal division;
- global elite.

Show roughly 20 players around the user’s level rather than only one huge global rank.

## Ethical guardrails

Do not use:

- streaks that reset to zero after one missed day;
- fake scarcity;
- fake countdowns;
- forced invitations;
- loss-chasing offers;
- pay-to-win items;
- coin bankruptcy that blocks normal play;
- undisclosed reward odds;
- rigged card sequences;
- hidden bot substitution;
- artificial near-miss animations.

Use:

- optional reminders;
- resumable progress;
- transparent pricing;
- session-end summaries;
- play-time controls;
- no penalty for taking a break;
- cosmetic and learning-based purchases.

---

# Technical architecture and independent-delivery boundary

## Independence rule

This game must be independently buildable, testable, deployable, and releasable. It may reuse platform packages, but it must not import another game's rules, state, screens, ranking logic, or release lifecycle.

Use these dependency rules:

- `table_game_home` may depend on the game integration interface.
- The game presentation package may depend on shared UI primitives.
- The game feature package may depend on its own rules client and shared platform clients.
- The server game adapter may depend on its own pure rules crate and shared infrastructure abstractions.
- The pure rules crate must not depend on Flutter, Axum, databases, Redis, analytics, payments, or another game.
- Shared infrastructure must not contain game-specific scoring rules.

This allows one game to be disabled, upgraded, rolled back, or regionally restricted without affecting the others.

## Recommended repository structure

```text
apps/
  table_game_flutter/
    lib/
      home/
      shared_cards/
      shared_lobby/
      shared_profile/
      games/gulam_chor/
services/
  table_game_api/
crates/
  game_platform_core/
  game_protocol/
  rating_core/
  replay_core/
  fairness_core/
  gulam_chor_core/
  gulam_chor_server/
```

A modular monorepo is recommended initially. The boundaries should be strong enough to extract a game service later if scale or team ownership requires it.

## Client architecture

Recommended client: **Flutter** for Android, iOS, and Web.

Layers:

1. **Presentation:** screens, card layouts, animation, sound, accessibility.
2. **Feature controller:** maps server events to UI state and sends commands.
3. **Game protocol client:** typed commands, events, snapshots, version negotiation.
4. **Shared platform clients:** account, lobby, friends, inventory, analytics, remote configuration.

The client is never authoritative for shuffle, legal moves, scoring, hidden information, match completion, or rating changes.

## Backend architecture

Recommended backend: **Rust + Axum**, with WebSockets for live matches.

Core components:

- identity and profile;
- game catalogue;
- lobby and room service;
- matchmaking;
- authoritative match session;
- game-specific server adapter;
- deterministic rules crate;
- secure shuffle and fairness proof;
- event log and replay;
- rating service where applicable;
- anti-abuse and reporting;
- inventory and purchases;
- analytics export.

Use PostgreSQL for durable user, match, rating, inventory, and purchase data. Use Redis for ephemeral rooms, matchmaking queues, presence, and short reconnect snapshots. The authoritative event log must be durably persisted before competitive rewards are finalized.

## Deterministic rules interface

```rust
pub trait CardGame {
    type Command;
    type Event;
    type State;
    type PublicConfig;
    type PlayerView;

    fn initial_state(config: Self::PublicConfig) -> Self::State;
    fn validate(
        state: &Self::State,
        actor: PlayerId,
        command: &Self::Command,
    ) -> Result<(), RuleError>;
    fn apply(
        state: &mut Self::State,
        actor: PlayerId,
        command: Self::Command,
    ) -> Result<Vec<Self::Event>, RuleError>;
    fn view_for(state: &Self::State, viewer: Viewer) -> Self::PlayerView;
}
```

Rules requirements:

- deterministic transitions;
- no duplicate or missing cards;
- hidden-information redaction;
- replay from events;
- versioned rule packs;
- property-based tests;
- bot and simulator hooks;
- forward-compatible event envelopes.

## WebSocket protocol

Client commands:

```text
join_match
ready
submit_game_action
request_snapshot
ack_event
leave_match
report_player
```

Server messages:

```text
match_joined
match_snapshot
match_event
command_rejected
turn_timer
player_connection_changed
match_completed
rating_updated
```

Every envelope should include:

```json
{
  "protocol_version": 1,
  "game_id": "gulam_chor",
  "match_id": "uuid",
  "sequence": 42,
  "message_type": "match_event",
  "payload": {}
}
```

Commands need client-generated idempotency IDs. Events need monotonically increasing server sequence numbers.

## Fair shuffle and replay

Recommended competitive flow:

1. Generate a cryptographically secure server seed.
2. Publish a commitment hash before the deal.
3. Shuffle server-side using a documented algorithm and version.
4. Persist the seed securely with the match record.
5. Reveal verification material after the match where safe.
6. Reproduce the deal in a replay verifier.

Never expose seed material during a live match. Casual bot matches may use a simpler path, but must still avoid engagement-based card manipulation.

## Reliability

- Reconnect restores a player-specific redacted snapshot.
- Replayed commands are idempotent.
- Server timeout policy is part of the rule pack.
- Competitive match completion survives a service restart.
- A rules-version identifier is persisted with every match.
- Client versions that cannot interpret the active protocol are rejected before queue entry.

## Testing strategy

Required automated tests:

- unit tests for every rule and tie-break;
- property-based card conservation;
- hidden-view leakage tests;
- deterministic replay tests;
- command fuzzing;
- invalid-turn tests;
- timer expiry tests;
- reconnect and duplicate-command tests;
- bot-versus-bot simulation;
- client golden tests for important states;
- accessibility tests for card readability and touch targets;
- load tests for concurrent rooms.

# Table Game Home integration contract

The Table Game Home screen is a catalogue and launcher. It must not understand game-specific rules.

## Game manifest

Each game publishes a versioned manifest:

```json
{
  "game_id": "gulam_chor",
  "display_name": "Gulam Chor",
  "short_description": "Make pairs, pass the Chor, bluff your friends, and avoid the final Jack.",
  "icon_asset": "assets/games/gulam_chor/icon.webp",
  "hero_asset": "assets/games/gulam_chor/hero.webp",
  "minimum_players": 2,
  "maximum_players": 8,
  "supports_bots": true,
  "supports_private_rooms": true,
  "supports_ranked": false,
  "supports_async": false,
  "minimum_client_version": "1.0.0",
  "rule_pack_version": "1.0.0",
  "availability": {
    "regions": ["IN"],
    "platforms": ["android", "ios", "web"]
  },
  "entry_routes": {
    "overview": "/games/gulam_chor",
    "play": "/games/gulam_chor/play",
    "resume": "/games/gulam_chor/resume/{match_id}"
  }
}
```

## Home-screen card

The home card should show only platform-level information:

- game artwork and title;
- one-line value proposition;
- player-count range;
- estimated match duration;
- `Play`, `Learn`, and `Resume` states;
- current event or season badge;
- installation/download state if feature modules are used.

Do not expose complicated rule options on the home screen. Those belong in the game's lobby.

## Launch interface

```dart
abstract interface class TableGameModule {
  String get gameId;
  Future<void> preload(GameLaunchContext context);
  Widget buildOverview(GameLaunchContext context);
  Widget buildLobby(GameLaunchContext context);
  Widget buildMatch(GameSession session);
  Widget buildReplay(String matchId);
  Future<bool> canResume(String matchId);
}
```

The home shell supplies authentication, locale, accessibility preferences, sound preferences, connectivity, profile summary, and deep-link parameters.

## Shared navigation

Every game must support:

```text
Home -> Game Overview -> Mode Selection -> Lobby/Matchmaking
     -> Match -> Result -> Rematch or Game Overview -> Home
```

Android back, browser back, app resume, and deep links must preserve the same state model.

## Shared identity and progression

Keep two layers separate:

- **Table Game profile:** avatar, friends, club, account level, cosmetics inventory, safety settings.
- **Game profile:** game rating, game mastery, game statistics, tutorials, badges, rule preferences.

A player can have a high platform level while remaining a beginner in a newly selected game.

## Shared economy

Permitted shared purchases:

- universal card backs;
- avatars;
- table themes where compatible;
- ad-free entitlement;
- optional family or analysis subscription.

Game rules, shuffle odds, ranked entry, hints during ranked play, and competitive powers must never be purchasable.

## Shared analytics envelope

Every event must contain:

```text
user_id or anonymous_id
session_id
game_id
game_version
rule_pack
mode
match_id when applicable
platform
region
experiment_assignments
timestamp
```

Common event names:

```text
game_card_viewed
game_selected
tutorial_started
tutorial_completed
queue_joined
match_started
match_completed
match_abandoned
rematch_selected
replay_opened
purchase_started
purchase_completed
report_submitted
```

Game-specific events belong to a namespaced schema.

## Feature flags and release isolation

Each game requires independent flags for:

- home visibility;
- new-player access;
- ranked queue;
- private rooms;
- bot play;
- experiments;
- monetisation;
- region availability;
- minimum version;
- emergency kill switch.

A failure in one game must not prevent the home screen or another game from loading.

# Research foundations used in this plan

The design decisions draw on the following research themes:

- Self-Determination Theory: autonomy, competence, and relatedness support enjoyment and continued play.
- Flow: challenge should remain close to skill, with manageable uncertainty and immediate feedback.
- Gamification research: points and leaderboards are feedback mechanisms, not substitutes for intrinsic fun.
- Competition and cheating research: an excessive focus on prizes and status can increase win-at-all-costs behaviour.
- Dark-pattern research: temporal, monetary, social, and psychological pressure may increase short-term activity while harming trust and wellbeing.
- Player- and data-driven balancing: simulations should be combined with interviews, observed sessions, and production telemetry.

Core references:

1. Ryan, Rigby, and Przybylski. *The Motivational Pull of Video Games: A Self-Determination Theory Approach*.
2. Moller, Kornfield, and Lu. *Competition and Digital Game Design: A Self-Determination Theory Perspective*.
3. Mekler et al. *Do Points, Levels and Leaderboards Harm Intrinsic Motivation?*
4. Larche et al. *The Relationship Between Skill-Challenge Balance, Game Expertise, Flow and the Urge to Keep Playing*.
5. Lee et al. *The Influence of Psychological Needs and Motivation on Game Cheating*.
6. Aagaard et al. *A Game of Dark Patterns: Designing Healthy, Highly-Engaging Mobile Games*.
7. Pfau and El-Nasr. *On Video Game Balancing: Joining Player- and Data-Driven Analytics*.
Additional Gulam Chor sources:

- MadFun Co., *Old Maid / Gulam Chor rules*.
- Observed family sessions are essential because the game's appeal depends on reactions, teasing, and house rules.
- Strategy extensions should be evaluated against a random-choice baseline to avoid presenting luck as skill.

