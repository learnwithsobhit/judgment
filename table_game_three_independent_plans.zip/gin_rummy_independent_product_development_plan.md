# Gin Rummy — Independent Digital Product and Development Plan

**Document status:** Draft v1.0  
**Audience:** Product owner, game designer, UX designer, Flutter engineers, Rust engineers, QA, data, marketing, and operations  
**Delivery model:** Independently releasable game module inside the future Table Game application  
**Recommended client/backend:** Flutter + Rust/Axum + WebSockets + PostgreSQL + Redis


## Purpose

This is the authoritative product and engineering plan for **Gin Rummy**. A team should be able to develop and release this game without waiting for either of the other game modules. At portfolio level, the module will appear as one selectable game on the shared **Table Game Home** screen.

## Product principle

Encourage repeat play through mastery, fairness, social connection, cultural identity, and fast rematches—not through gambling pressure, fake scarcity, or purchasable advantage.

# Product scope and non-goals

## Primary audience

- global two-player strategy-card users;
- Indian players seeking non-partnership ranked competition;
- learners who want understandable coaching;
- experienced Gin players dissatisfied with casino-style products.

## MVP goal

Deliver a trustworthy 1v1 Gin Rummy experience with bots, real-time matchmaking, correct scoring, reconnect, replay, and Glicko-2-ready match results.

## Non-goals for first release

- cash entry, wagering, or redeemable virtual balance;
- large multiplayer tables;
- every Gin variant at launch;
- live coach recommendations during ranked play;
- hidden bot substitution;
- jackpot or slot-machine presentation.

# Gin Rummy game-domain specification

## State machine

```text
CREATED
 -> WAITING_FOR_PLAYERS
 -> READY_CHECK
 -> SHUFFLE_COMMITTED
 -> DEALING
 -> TURN_DRAW
 -> TURN_DISCARD
 -> TURN_DRAW ...
 -> KNOCK_DECLARED | GIN_DECLARED | STOCK_EXHAUSTED
 -> OPPONENT_LAYOFF
 -> HAND_SCORING
 -> NEXT_HAND | MATCH_COMPLETE
```

## Core commands

```text
ready
draw_from_stock
draw_from_discard
discard_card
knock
declare_gin
submit_layoff
confirm_hand_resolution
request_reconnect_snapshot
```

## Core events

```text
hand_started
private_hand_dealt
upcard_revealed
card_drawn_private
card_drawn_from_discard
card_discarded
knock_declared
gin_declared
layoff_applied
undercut_resolved
hand_score_updated
match_winner_resolved
```

## Essential invariants

- stock, discard pile, and both hands contain unique cards;
- a normal turn consists of exactly one draw and one discard;
- a card drawn from the discard cannot be immediately returned where prohibited by the rule pack;
- deadwood and meld calculation is deterministic;
- knock threshold follows the active variant;
- layoff occurs only when permitted;
- score bonuses follow the persisted scoring pack;
- hidden stock and opponent hand never appear in the wrong player view.

# Gin Rummy screen map

```text
Home Game Card
 -> Gin Rummy Overview
 -> Learn / Play
 -> Quick / Ranked / Private / Lab
 -> Matchmaking or Lobby
 -> Game Table
 -> Knock/Gin Resolution
 -> Hand Score
 -> Match Result
 -> Pivotal Decision / Replay / Rematch
```

Critical table UX:

- large readable ten-card hand;
- stable manual ordering;
- optional sorting by rank, suit, or meld;
- explicit stock and discard targets;
- accidental-discard protection;
- deadwood counter;
- non-intrusive knock affordance;
- clear layoff sequence;
- no card reordering surprise during reveal.

# Gin Rummy delivery backlog

## Epic GR-1: Rules

- meld and deadwood evaluator;
- draw/discard validation;
- knock, Gin, undercut, and layoff;
- scoring packs;
- stock exhaustion;
- deterministic replay.

## Epic GR-2: Table UX

- hand layout;
- manual ordering;
- draw and discard interactions;
- knock confirmation;
- reveal and scoring;
- accessibility and one-handed layouts.

## Epic GR-3: Opponents and multiplayer

- beginner/intermediate bots;
- private duel;
- public matchmaking;
- reconnect;
- resign and timeout;
- rematch.

## Epic GR-4: Competitive integrity

- Glicko-2;
- rating confidence;
- repeated-opponent detection;
- bot/automation signals;
- replay review;
- seasonal division display.

## Epic GR-5: Mastery

- Gin Lab;
- pivotal-turn analysis;
- Leakage Meter;
- Information Duel;
- Position Arena;
- advanced coach subscription.

# Gin Rummy release stages

## Alpha

- complete rules against bots;
- one scoring pack;
- stable hand controls;
- deterministic replay.

## Private beta

- invited 1v1;
- reconnect;
- rating shadow calculation;
- trust and usability research.

## Public MVP

- casual matchmaking;
- bot practice;
- private tables;
- replay;
- tutorial;
- ad-free/cosmetic monetisation.

## Ranked release

- Glicko-2;
- race-to-100 queue;
- anti-boosting controls;
- seasonal divisions;
- public fairness verifier.

# Gin Rummy definition of done

The initial independent game is complete when:

- all scoring and tie scenarios are tested;
- accidental discard remains below the agreed threshold;
- a full 1v1 match survives reconnect and process restart;
- ratings are reproducible from completed match records;
- player-specific snapshots leak no hidden cards;
- replay reproduces stock, discard, hand resolution, and scores;
- bots use only legally visible information;
- the home shell can launch, resume, and disable the module independently;
- security, rule, UX, accessibility, and production-readiness reviews pass.

# Detailed game product design

## Core rules to implement

Gin Rummy is normally a two-player game using a 52-card deck without jokers. Each player receives 10 cards and forms:

- sets of three or four equal ranks;
- runs of at least three consecutive cards in one suit.

Each turn:

1. draw from stock or discard;
2. discard one card.

Unmatched cards are deadwood. A player can commonly knock with deadwood of 10 or less, or go Gin with zero deadwood. The opponent may lay off cards after a normal knock. If the opponent has equal or lower deadwood, an undercut occurs.

Published scoring bonuses differ. Implement named scoring packs rather than one hidden default.

## Product problems

### Hidden expert depth

Beginners see only melds. Experts consider:

- card utility;
- overlapping meld paths;
- safe discards;
- opponent pickup signals;
- stock depth;
- undercut risk;
- score state;
- knock timing.

### Crowded market

Large apps already provide multiplayer, leaderboards, coins, casino tables, and jackpots. A new title needs a stronger identity than visual polish.

### Trust

Bad draw sequences are often interpreted as rigging, especially when virtual coins or entry costs are involved.

### Control risk

Accidental discards, automatic card rearrangement, unclear grouping, or premature knocks can make the interface feel responsible for the loss.

## Product thesis

> **Build the most trustworthy and educational Gin Rummy duel, positioned around inference and timing rather than simulated gambling.**

Core loop:

1. Form a theory for the hand.
2. Observe opponent pickups and discards.
3. Revise the theory.
4. Choose attack, defence, or knock.
5. Reveal how accurate the inference was.

Differentiators:

- trustworthy shuffle;
- excellent controls;
- explainable replay;
- meaningful rank;
- AI coaching based on actual decisions.

## Modes

### Ranked Classic

- 1v1;
- race to 100;
- Glicko-2;
- no paid entry;
- no live gameplay chat;
- replay and strict reconnect policy.

### Quick Knock

- one hand;
- 3–5 minutes;
- casual;
- no serious rating.

### Best-of-Three Duel

- fixed multi-hand match;
- reduces luck;
- suitable for tournaments.

### Private Table

- friend link;
- scoring-pack choice;
- relaxed timers;
- optional preset chat.

### Gin Lab

Daily positions:

- draw stock or discard;
- best discard;
- knock or continue;
- estimate opponent intent;
- minimise expected deadwood;
- choose defensive versus offensive play.

### Information Duel — proposed new mode

Players privately predict:

- opponent deadwood range;
- likely target rank or suit;
- whether the opponent will knock soon.

Predictions do not alter the match score. They create a separate “Reader” mastery metric.

### Position Arena — proposed new mode

Players independently solve the same recorded mid-game position against a fixed policy.

Rank by:

- expected score;
- move quality;
- decision time;
- consistency.

This creates asynchronous, collusion-resistant competition.

## Strategy model

Gin Rummy AI research usefully decomposes decisions into:

1. draw policy;
2. discard policy;
3. knock policy.

The product coach should use the same structure.

### Draw policy

Evaluate:

- immediate meld creation;
- run extension;
- flexibility;
- information leaked by taking the upcard;
- whether leaving the card helps the opponent.

### Discard policy

A discard is both card management and information.

Evaluate:

- deadwood value;
- future meld paths;
- opponent pickup history;
- suit/rank danger;
- information leakage;
- stock pressure.

Add a post-match **Leakage Meter** showing risky discards based only on public opponent evidence.

### Knock policy

Low deadwood does not always imply an immediate knock.

Consider:

- turns elapsed;
- number of melded cards;
- likely opponent deadwood;
- chance of Gin;
- undercut risk;
- score state;
- cards remaining in stock.

Published AI studies suggest that knock timing should be more nuanced than a simple threshold rule.

### Opponent modelling

Use only public evidence:

- cards taken from discard;
- cards discarded;
- cards declined;
- timing;
- stock depth.

Coach output should express probability and uncertainty, never certainty about hidden cards.

## UX

Hand controls:

- drag-and-drop;
- tap selection;
- discard confirmation option;
- manual grouping;
- sort by suit, rank, or meld;
- clear deadwood counter;
- large cards;
- no auto-rearrangement during reveal;
- configurable animation speed.

Knock controls:

- subtle enabled button;
- deadwood shown;
- beginner confirmation;
- advanced quick-knock option.

Meld visualisation:

- soft grouping;
- alternative meld toggle;
- ghost outlines;
- deadwood area;
- no forced single “correct” grouping.

Post-match flow:

1. Result.
2. Rating movement.
3. Pivotal turn.
4. Better alternative.
5. Rematch.

## Ranking and anti-cheat

Use Glicko-2 with:

- rating;
- rating deviation;
- volatility.

Matchmaking:

- protected new-player pool;
- gradually widening search;
- preferred match length;
- visible estimated opponent band;
- seasonal divisions over stable MMR;
- soft, not total, resets.

Risks remain despite 1v1 play:

- account boosting;
- deliberate loss transfer;
- bots;
- automation;
- account sharing;
- disconnect abuse.

Controls:

- repeated-pair detection;
- action-timing analysis;
- impossible consistency models;
- device and network risk signals;
- replay review;
- delayed rewards for suspicious matches;
- appeals.

## AI

Bot levels:

- Beginner: obvious melds and human-like errors;
- Intermediate: deadwood and basic opponent awareness;
- Advanced: opponent modelling, Monte Carlo evaluation, dynamic knock policy;
- Expert: mixed strategy and rigorous evaluation, without hidden-card access.

Explainable coach output:

- selected action;
- legal alternatives;
- deadwood impact;
- meld flexibility;
- opponent risk;
- knock/undercut risk;
- confidence;
- one-sentence explanation.

A strong research direction is:

> **Explainable opponent modelling for Gin Rummy from public action history.**

## Monetisation

Use:

- card and table cosmetics;
- premium replay archive;
- advanced coaching;
- ad-free purchase;
- tournament themes;
- club tools;
- optional commentary packs.

Avoid:

- casino-chip dependency;
- jackpots;
- paid random rewards;
- pay-to-enter ranked matches;
- energy systems;
- better odds for paying users.

## Gin Rummy MVP

Must have:

- exact rule engine;
- named scoring packs;
- offline bots;
- real-time 1v1;
- Glicko-2;
- reconnect;
- replay;
- safe sorting and grouping;
- deadwood calculation;
- knock/Gin/undercut scoring;
- tutorial;
- fairness page;
- telemetry.

Next:

- Gin Lab;
- tournaments;
- coach;
- clubs;
- Position Arena;
- Information Duel.

## Gin Rummy go/no-go criteria

Proceed when:

- first-match completion exceeds 85%;
- accidental discard is below 0.5% of turns;
- 35%+ of completed matches lead to another queue or rematch;
- users can explain knock, Gin, and undercut after tutorial;
- rating bands predict match outcomes reasonably;
- fewer than 5% of surveyed players suspect hidden bots when none are present;
- post-match insights improve return without increasing frustration.

---

# Engagement and psychology model

## The problem with simply copying cards onto a screen

A technically correct digital implementation can still feel flat because the physical game also contains:

- face-to-face reactions;
- teasing and conversation;
- tactile card handling;
- visible shuffling;
- natural teaching;
- family rules and cultural identity;
- frictionless rematches.

A screen removes much of this. If the product only reproduces card movement, it preserves rules but loses experience.

## Root cause

Players return when the game repeatedly satisfies five needs:

1. **Competence:** “I am understanding and improving.”
2. **Autonomy:** “I chose my strategy and preferred way to play.”
3. **Relatedness:** “I played with people who mattered or felt socially connected.”
4. **Fairness:** “Cards, scoring, matchmaking, and opponents were trustworthy.”
5. **Rhythm:** “The match moved cleanly through anticipation, choice, reveal, and resolution.”

Self-Determination Theory research on games associates autonomy, competence, and relatedness with enjoyment and future play. It also connects intuitive controls with competence and immersion. Research on leaderboards suggests that points and ranks may guide performance, but do not create intrinsic enjoyment by themselves. Research on flow indicates that challenge should remain near the player’s skill level.

## So how can we solve the problem?

Build a **mastery-first retention loop**:

1. Give the player a meaningful decision.
2. Make the result understandable.
3. Show one useful learning insight.
4. Offer a quick rematch or a related challenge.
5. Make progression visible without punishing the player for taking a break.

The game should be enjoyable before rewards are added.

---

# Psychology-backed product rules

## Competence

Every completed match should answer:

- Which decision mattered most?
- What happened because of it?
- What could I try next time?

Implement:

- one post-match insight rather than a lecture;
- skill-specific statistics;
- decision bookmarks in replay;
- optional explanations;
- beginner leagues;
- personal-best progress.

Avoid:

- unexplained rating movement;
- humiliating loss screens;
- bots presented as humans;
- random prizes portrayed as skill.

## Autonomy

Let players choose:

- Classic versus modern modes;
- ranked, casual, private, puzzle, or bot play;
- animation speed;
- manual or assisted sorting;
- preferred match duration;
- language, card design, and table theme;
- whether the coach is enabled.

Do not force unnecessary reward screens before a rematch.

## Relatedness

Use:

- immediate rematches;
- friend links and room codes;
- clubs based on family, city, workplace, or language;
- preset respectful reactions;
- post-match reactions;
- shareable replay moments;
- teach-a-friend rooms.

For child-accessible modes, do not expose unrestricted stranger chat.

## Flow

Use:

- calibrated matchmaking;
- bot personalities and difficulty bands;
- adaptive tutorials;
- separate fast and thoughtful queues;
- turn-time banks;
- protection from early expert mismatches.

## Leaderboards

A global leaderboard mainly motivates elite players. Most users need a reachable comparison.

Offer:

- friends;
- nearby rating group;
- city and region;
- club;
- weekly improvement;
- skill-specific badges;
- seasonal division;
- global elite.

Show roughly 20 players around the user’s level rather than only one huge global rank.

## Ethical guardrails

Do not use:

- streaks that reset to zero after one missed day;
- fake scarcity;
- fake countdowns;
- forced invitations;
- loss-chasing offers;
- pay-to-win items;
- coin bankruptcy that blocks normal play;
- undisclosed reward odds;
- rigged card sequences;
- hidden bot substitution;
- artificial near-miss animations.

Use:

- optional reminders;
- resumable progress;
- transparent pricing;
- session-end summaries;
- play-time controls;
- no penalty for taking a break;
- cosmetic and learning-based purchases.

---

# Technical architecture and independent-delivery boundary

## Independence rule

This game must be independently buildable, testable, deployable, and releasable. It may reuse platform packages, but it must not import another game's rules, state, screens, ranking logic, or release lifecycle.

Use these dependency rules:

- `table_game_home` may depend on the game integration interface.
- The game presentation package may depend on shared UI primitives.
- The game feature package may depend on its own rules client and shared platform clients.
- The server game adapter may depend on its own pure rules crate and shared infrastructure abstractions.
- The pure rules crate must not depend on Flutter, Axum, databases, Redis, analytics, payments, or another game.
- Shared infrastructure must not contain game-specific scoring rules.

This allows one game to be disabled, upgraded, rolled back, or regionally restricted without affecting the others.

## Recommended repository structure

```text
apps/
  table_game_flutter/
    lib/
      home/
      shared_cards/
      shared_lobby/
      shared_profile/
      games/gin_rummy/
services/
  table_game_api/
crates/
  game_platform_core/
  game_protocol/
  rating_core/
  replay_core/
  fairness_core/
  gin_rummy_core/
  gin_rummy_server/
```

A modular monorepo is recommended initially. The boundaries should be strong enough to extract a game service later if scale or team ownership requires it.

## Client architecture

Recommended client: **Flutter** for Android, iOS, and Web.

Layers:

1. **Presentation:** screens, card layouts, animation, sound, accessibility.
2. **Feature controller:** maps server events to UI state and sends commands.
3. **Game protocol client:** typed commands, events, snapshots, version negotiation.
4. **Shared platform clients:** account, lobby, friends, inventory, analytics, remote configuration.

The client is never authoritative for shuffle, legal moves, scoring, hidden information, match completion, or rating changes.

## Backend architecture

Recommended backend: **Rust + Axum**, with WebSockets for live matches.

Core components:

- identity and profile;
- game catalogue;
- lobby and room service;
- matchmaking;
- authoritative match session;
- game-specific server adapter;
- deterministic rules crate;
- secure shuffle and fairness proof;
- event log and replay;
- rating service where applicable;
- anti-abuse and reporting;
- inventory and purchases;
- analytics export.

Use PostgreSQL for durable user, match, rating, inventory, and purchase data. Use Redis for ephemeral rooms, matchmaking queues, presence, and short reconnect snapshots. The authoritative event log must be durably persisted before competitive rewards are finalized.

## Deterministic rules interface

```rust
pub trait CardGame {
    type Command;
    type Event;
    type State;
    type PublicConfig;
    type PlayerView;

    fn initial_state(config: Self::PublicConfig) -> Self::State;
    fn validate(
        state: &Self::State,
        actor: PlayerId,
        command: &Self::Command,
    ) -> Result<(), RuleError>;
    fn apply(
        state: &mut Self::State,
        actor: PlayerId,
        command: Self::Command,
    ) -> Result<Vec<Self::Event>, RuleError>;
    fn view_for(state: &Self::State, viewer: Viewer) -> Self::PlayerView;
}
```

Rules requirements:

- deterministic transitions;
- no duplicate or missing cards;
- hidden-information redaction;
- replay from events;
- versioned rule packs;
- property-based tests;
- bot and simulator hooks;
- forward-compatible event envelopes.

## WebSocket protocol

Client commands:

```text
join_match
ready
submit_game_action
request_snapshot
ack_event
leave_match
report_player
```

Server messages:

```text
match_joined
match_snapshot
match_event
command_rejected
turn_timer
player_connection_changed
match_completed
rating_updated
```

Every envelope should include:

```json
{
  "protocol_version": 1,
  "game_id": "gin_rummy",
  "match_id": "uuid",
  "sequence": 42,
  "message_type": "match_event",
  "payload": {}
}
```

Commands need client-generated idempotency IDs. Events need monotonically increasing server sequence numbers.

## Fair shuffle and replay

Recommended competitive flow:

1. Generate a cryptographically secure server seed.
2. Publish a commitment hash before the deal.
3. Shuffle server-side using a documented algorithm and version.
4. Persist the seed securely with the match record.
5. Reveal verification material after the match where safe.
6. Reproduce the deal in a replay verifier.

Never expose seed material during a live match. Casual bot matches may use a simpler path, but must still avoid engagement-based card manipulation.

## Reliability

- Reconnect restores a player-specific redacted snapshot.
- Replayed commands are idempotent.
- Server timeout policy is part of the rule pack.
- Competitive match completion survives a service restart.
- A rules-version identifier is persisted with every match.
- Client versions that cannot interpret the active protocol are rejected before queue entry.

## Testing strategy

Required automated tests:

- unit tests for every rule and tie-break;
- property-based card conservation;
- hidden-view leakage tests;
- deterministic replay tests;
- command fuzzing;
- invalid-turn tests;
- timer expiry tests;
- reconnect and duplicate-command tests;
- bot-versus-bot simulation;
- client golden tests for important states;
- accessibility tests for card readability and touch targets;
- load tests for concurrent rooms.

# Table Game Home integration contract

The Table Game Home screen is a catalogue and launcher. It must not understand game-specific rules.

## Game manifest

Each game publishes a versioned manifest:

```json
{
  "game_id": "gin_rummy",
  "display_name": "Gin Rummy",
  "short_description": "Draw, discard, read the opponent, and choose the right time to knock.",
  "icon_asset": "assets/games/gin_rummy/icon.webp",
  "hero_asset": "assets/games/gin_rummy/hero.webp",
  "minimum_players": 2,
  "maximum_players": 2,
  "supports_bots": true,
  "supports_private_rooms": true,
  "supports_ranked": true,
  "supports_async": true,
  "minimum_client_version": "1.0.0",
  "rule_pack_version": "1.0.0",
  "availability": {
    "regions": ["IN"],
    "platforms": ["android", "ios", "web"]
  },
  "entry_routes": {
    "overview": "/games/gin_rummy",
    "play": "/games/gin_rummy/play",
    "resume": "/games/gin_rummy/resume/{match_id}"
  }
}
```

## Home-screen card

The home card should show only platform-level information:

- game artwork and title;
- one-line value proposition;
- player-count range;
- estimated match duration;
- `Play`, `Learn`, and `Resume` states;
- current event or season badge;
- installation/download state if feature modules are used.

Do not expose complicated rule options on the home screen. Those belong in the game's lobby.

## Launch interface

```dart
abstract interface class TableGameModule {
  String get gameId;
  Future<void> preload(GameLaunchContext context);
  Widget buildOverview(GameLaunchContext context);
  Widget buildLobby(GameLaunchContext context);
  Widget buildMatch(GameSession session);
  Widget buildReplay(String matchId);
  Future<bool> canResume(String matchId);
}
```

The home shell supplies authentication, locale, accessibility preferences, sound preferences, connectivity, profile summary, and deep-link parameters.

## Shared navigation

Every game must support:

```text
Home -> Game Overview -> Mode Selection -> Lobby/Matchmaking
     -> Match -> Result -> Rematch or Game Overview -> Home
```

Android back, browser back, app resume, and deep links must preserve the same state model.

## Shared identity and progression

Keep two layers separate:

- **Table Game profile:** avatar, friends, club, account level, cosmetics inventory, safety settings.
- **Game profile:** game rating, game mastery, game statistics, tutorials, badges, rule preferences.

A player can have a high platform level while remaining a beginner in a newly selected game.

## Shared economy

Permitted shared purchases:

- universal card backs;
- avatars;
- table themes where compatible;
- ad-free entitlement;
- optional family or analysis subscription.

Game rules, shuffle odds, ranked entry, hints during ranked play, and competitive powers must never be purchasable.

## Shared analytics envelope

Every event must contain:

```text
user_id or anonymous_id
session_id
game_id
game_version
rule_pack
mode
match_id when applicable
platform
region
experiment_assignments
timestamp
```

Common event names:

```text
game_card_viewed
game_selected
tutorial_started
tutorial_completed
queue_joined
match_started
match_completed
match_abandoned
rematch_selected
replay_opened
purchase_started
purchase_completed
report_submitted
```

Game-specific events belong to a namespaced schema.

## Feature flags and release isolation

Each game requires independent flags for:

- home visibility;
- new-player access;
- ranked queue;
- private rooms;
- bot play;
- experiments;
- monetisation;
- region availability;
- minimum version;
- emergency kill switch.

A failure in one game must not prevent the home screen or another game from loading.

# Research foundations used in this plan

The design decisions draw on the following research themes:

- Self-Determination Theory: autonomy, competence, and relatedness support enjoyment and continued play.
- Flow: challenge should remain close to skill, with manageable uncertainty and immediate feedback.
- Gamification research: points and leaderboards are feedback mechanisms, not substitutes for intrinsic fun.
- Competition and cheating research: an excessive focus on prizes and status can increase win-at-all-costs behaviour.
- Dark-pattern research: temporal, monetary, social, and psychological pressure may increase short-term activity while harming trust and wellbeing.
- Player- and data-driven balancing: simulations should be combined with interviews, observed sessions, and production telemetry.

Core references:

1. Ryan, Rigby, and Przybylski. *The Motivational Pull of Video Games: A Self-Determination Theory Approach*.
2. Moller, Kornfield, and Lu. *Competition and Digital Game Design: A Self-Determination Theory Perspective*.
3. Mekler et al. *Do Points, Levels and Leaderboards Harm Intrinsic Motivation?*
4. Larche et al. *The Relationship Between Skill-Challenge Balance, Game Expertise, Flow and the Urge to Keep Playing*.
5. Lee et al. *The Influence of Psychological Needs and Motivation on Game Cheating*.
6. Aagaard et al. *A Game of Dark Patterns: Designing Healthy, Highly-Engaging Mobile Games*.
7. Pfau and El-Nasr. *On Video Game Balancing: Joining Player- and Data-Driven Analytics*.
Additional Gin Rummy sources:

- Bicycle Cards, *Gin Rummy rules*.
- Eicholtz et al., *Heisenbot: A Rule-Based Game Agent for Gin Rummy*.
- Maravich, Neller, and Neller, *Knocking in the Game of Gin Rummy*.
- Neller and collaborators, work on opponent modelling and meld distance in Gin Rummy.

